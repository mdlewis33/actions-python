class ItemDatabase:
    def __init__(self) -> None:
        pass

    def get(self, item: str) -> float:
        pass
